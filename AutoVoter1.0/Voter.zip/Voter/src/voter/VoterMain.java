package voter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class VoterMain implements Runnable {
	public final static long NANO_SECONDS_IN_HOUR = 3600000000000l;

	public void run() {

		// open the file scan in all the accounts
		File accountsFile = new File("accounts.txt");
		Scanner sc = null;
		try {
			sc = new Scanner(accountsFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		if (sc == null) {
			// there was a problem opening the file
			return;
		}

		Account account = null;
		int line = 0;
		List<Account> accounts = new LinkedList<Account>();
		while (sc.hasNext()) {
			String next = sc.nextLine();
			if (next.equals("")) {
				continue;
			} else if (next.startsWith("#")) {
				continue;
			}

			if (line == 0) {
				account = new Account();
				// read in the user line
				account.setUsername(next);
				line++;
			} else if (line == 1) {
				// read in the password line
				account.setPassword(next);
				line++;
			} else if (line == 2) {
				// read in the last time the account was used
				account.setTime(Long.parseLong(next));
				accounts.add(account);
				line = 0;
			}
		}

		// now that all the accounts are stored in accounts go through them and
		// do the request for each one if its time
		for (Account a : accounts) {
			boolean timeUp = false;
			// first check to see if the time is up on the account
			long time = a.getTime();
			if (time == 0) { // 0 is default
				// time is up
				timeUp = true;
			} else if ((time + (VoterMain.NANO_SECONDS_IN_HOUR * 11)) > System.nanoTime()) {
				timeUp = true;
			}

			if (timeUp) {
				doAccount(a.getUsername(), a.getPassword());
				//now we must write out the whole file again
			}
		}

	}
	
	public static void updateFile(List<Account> accounts){
		for(Account a : accounts){
			
		}
	}

	public static void doAccount(String username, String password) {

		// URL
		String textUrl = "http://66.45.229.98/Vendetta/Vote/";
		String scriptName = "checklogin.php";

		// String username = "nick";
		// String password = "blapass";

		try {
			// Construct data
			String data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");
			data += "&" + URLEncoder.encode("secret", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
			// Send data
			URL url = new URL(textUrl + scriptName);
			URLConnection conn = url.openConnection();
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			// Get the response
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) {
				// Process line...
				System.out.println("Output: " + line);
			}
			wr.close();
			rd.close();

		} catch (Exception e) {
		}

	}
}
