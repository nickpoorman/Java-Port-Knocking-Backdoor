#if !defined(AFX_STDAFX_H__93345D3A_0CF1_4A56_B453_22701C1CCB5A__INCLUDED_)
#define AFX_STDAFX_H__93345D3A_0CF1_4A56_B453_22701C1CCB5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <Windows.h>


#endif // !defined(AFX_STDAFX_H__93345D3A_0CF1_4A56_B453_22701C1CCB5A__INCLUDED_)
