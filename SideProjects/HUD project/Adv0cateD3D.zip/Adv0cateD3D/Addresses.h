/*Anakrime + Adv0cate + Hans211 + Brom + ATX Coder + Gordon + Croner + Warlord*/
//--------BASE--------------
#define ADR_SERVERBASE		0x000000
#define ADR_PLAYERBASE		0x000000
#define ADR_ANTIBAN			0x000000