#include<Windows.h>
/*Anakrime + Adv0cate + Hans211 + Brom + ATX Coder + Gordon + Croner + Warlord*/
void RebuildMenu(void);
void HacksInGame(void);
void HacksInServer(void);
void AsmIn(void);
void CmdIn(void);
void AntiBan(void);
void EndProcess(void);

extern int CT_Visual;
extern int CT_Player1;
extern int CT_Player2;
extern int CT_Weapon;
extern int CT_Server;
extern int CT_Gps;
extern int CT_Px;

extern int CH_Chams;
extern int CH_ColorC1;
extern int CH_ColorC2;
extern int CH_ColorW;
extern int CH_Wire;
extern int CH_Wall;
extern int CH_Point;
extern int CH_Bright;
extern int CH_Cross;